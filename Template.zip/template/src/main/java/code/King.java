package code;

public class King extends GameCharacter{

    public static final String ANSI_CYAN = "\u001B[36m";

    public King(String name) {
        super(name);
        setPower(8);
        setAttack(8);
        setDefense(8);
        setHealing(7);
        setExtraScore(5);
    }

    @Override
    public void hit(GameCharacter opponent) {
        System.out.println(ANSI_RED + getName() + " struck " + opponent.getName() + " with Excalibur." + ANSI_RESET);
    }

    @Override
    public void greet(String message) {
        System.out.println(ANSI_CYAN + getName() + ANSI_RESET + ": " + ANSI_GREEN + message + ANSI_RESET);
    }

}
