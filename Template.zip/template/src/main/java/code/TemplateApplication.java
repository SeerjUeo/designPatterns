package code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplateApplication {

	public static void main(String[] args) {

		GameCharacter arthur = new King("Arthur");
		GameCharacter caradoc = new Knight("Caradoc");
		GameCharacter dagonet = new Soldier("Dagonet");
		GameCharacter lucius = new Peasant("Lucius");

		arthur.hit(lucius);
		arthur.greet("My name is Arthur.");
		System.out.print("Invincibility: " + arthur.calculateInvincibility());
		System.out.println();

		caradoc.greet("I'm the Great Caradoc.");
		System.out.print("Invincibility: " + caradoc.calculateInvincibility());
		System.out.println();

		dagonet.greet("I am Dagonet.");
		System.out.print("Invincibility: " + dagonet.calculateInvincibility());
		System.out.println();

		lucius.greet("OOUCH mmmmm Lucius.");
		System.out.print("Invincibility: " + lucius.calculateInvincibility());
		System.out.println();

		SpringApplication.run(TemplateApplication.class, args);

	}

}
