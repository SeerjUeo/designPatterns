package code;

public class Soldier extends GameCharacter {

    public static final String ANSI_BLUE = "\u001B[34m";

    public Soldier(String name) {
        super(name);
        setPower(4);
        setAttack(5);
        setDefense(4);
        setHealing(4);
    }

    @Override
    public void hit(GameCharacter opponent) {
        System.out.println(ANSI_RED + getName() + " slammed " + opponent.getName() + " with a mace." + ANSI_RESET);
    }

    @Override
    public void greet(String message) {
        System.out.println(ANSI_BLUE + getName() + ANSI_RESET + ": " + ANSI_GREEN + message + ANSI_RESET);
    }

}
