package code;

public abstract class GameCharacter {
    private String name;
    private int power;
    private int attack;
    private int defense;
    private int healing;
    private double extraScore = 1;

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";

    public GameCharacter(String name) {
        this.name = name;
    }

    public final double calculateInvincibility() {
        double invincibility = 0;

        invincibility = power + (attack * defense * extraScore) / 2 + healing * 1.5 * extraScore;

        return invincibility;
    }

    public void hit(GameCharacter opponent) {};
    public void greet(String message) {};

    public String getName() {
        return name;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public void setHealing(int healing) {
        this.healing = healing;
    }


    public void setExtraScore(double extraScore) {
        this.extraScore = extraScore;
    }
}
