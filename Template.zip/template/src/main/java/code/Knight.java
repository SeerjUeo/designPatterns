package code;

public class Knight extends GameCharacter {

    public static final String ANSI_PURPLE = "\u001B[35m";

    public Knight(String name) {
        super(name);
        setPower(6);
        setAttack(7);
        setDefense(7);
        setHealing(4);
        setExtraScore(1.5);
    }

    @Override
    public void hit(GameCharacter opponent) {
        System.out.println(ANSI_RED + getName() + " struck " + opponent.getName() + " with a sword." + ANSI_RESET);
    }

    @Override
    public void greet(String message) {
        System.out.println(ANSI_PURPLE + getName() + ANSI_RESET + ": " + ANSI_GREEN + message + ANSI_RESET);
    }

}
