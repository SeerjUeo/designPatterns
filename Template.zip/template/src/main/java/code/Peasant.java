package code;

public class Peasant extends GameCharacter{

    public Peasant(String name) {
        super(name);
       setPower(2);
       setAttack(2);
       setDefense(2);
       setHealing(5);
    }

    @Override
    public void hit(GameCharacter opponent) {
        System.out.println(ANSI_RED + getName() + " hit " + opponent.getName() + " with a pitchfork." + ANSI_RESET);
    }

    @Override
    public void greet(String message) {
        System.out.println(getName() + ": " + ANSI_GREEN + message + ANSI_RESET);
    }
}
