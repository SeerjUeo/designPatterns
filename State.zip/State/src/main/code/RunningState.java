public class RunningState implements OPossibleState {

    private MediaPlayer mediaPlayer;

    public RunningState(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
        System.out.println(ANSI_GREEN + "Running" + ANSI_RESET);
    }

    @Override
    public void start(MediaPlayer context) {
        System.out.println(ANSI_YELLOW + "Running already." + ANSI_RESET);
    }

    @Override
    public void stop(MediaPlayer context) {
        context.setCurrentState(new StoppedState(context));
    }

    @Override
    public void pause(MediaPlayer context) {
        context.setCurrentState(new PausedState(context));
    }

    //The diagram attached to project's acceptance criteria
    //does not include rewinding when the mediaPlayer is running
    //this feature was added because in reality you can rewind when the player is running
    //depending on the player
    @Override
    public void rewind(MediaPlayer context) {
        System.out.println(ANSI_GREEN + "Rewind" + ANSI_RESET);
    }
}
