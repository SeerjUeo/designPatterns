public class MediaPlayer {
    private OPossibleState currentState;

    public MediaPlayer() {
        this.currentState = new PausedState(this);
    }

    public void start() {
        currentState.start(this);
    }

    public void stop() {
        currentState.stop(this);
    }

    public void pause() {
        currentState.pause(this);
    }

    public void rewind() {
        currentState.rewind(this);
    }

    public OPossibleState getCurrentState() {
        return currentState;
    }

    public void setCurrentState(OPossibleState newState) {
        this.currentState = newState;
    }
}
