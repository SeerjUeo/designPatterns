public class StoppedState implements OPossibleState {

    private MediaPlayer mediaPlayer;

    public StoppedState(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
        System.out.println(ANSI_GREEN + "Stopped" + ANSI_RESET);
    }

    @Override
    public void start(MediaPlayer context) {
        context.setCurrentState(new RunningState(context));
    }

    @Override
    public void stop(MediaPlayer context) {
        System.out.println(ANSI_YELLOW + "Stopped already." + ANSI_RESET);
    }

    @Override
    public void pause(MediaPlayer context) {
        System.out.println(ANSI_GREEN + "Stopped" + ANSI_RESET);
    }

    @Override
    public void rewind(MediaPlayer context) {
        context.setCurrentState(new RunningState(context));
    }
}
