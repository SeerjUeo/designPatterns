public class PausedState implements OPossibleState {

    private MediaPlayer mediaPlayer;

    public PausedState(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
        System.out.println(ANSI_GREEN + "Paused" + ANSI_RESET);
    }

    @Override
    public void start(MediaPlayer context) {
        context.setCurrentState(new RunningState(context));
    }

    @Override
    public void stop(MediaPlayer context) {
        context.setCurrentState(new StoppedState(context));
    }

    @Override
    public void pause(MediaPlayer context) {
        System.out.println(ANSI_YELLOW + "Paused already." + ANSI_RESET);
    }

    //The diagram attached to project's acceptance criteria
    //does not include rewinding when the player is paused
    //this feature was added because in reality you can rewind when the player is running
    //depending on the player
    @Override
    public void rewind(MediaPlayer context) {
        context.setCurrentState(new RunningState(context));
    }
}
