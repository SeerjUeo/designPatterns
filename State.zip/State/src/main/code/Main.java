public class Main {
    public static void main(String[] args) {
        MediaPlayer spotify = new MediaPlayer();
        spotify.start();
        spotify.start();

        spotify.pause();
        spotify.pause();

        spotify.rewind();
        spotify.rewind();
        spotify.rewind();

        spotify.stop();
        spotify.stop();

    }
}
