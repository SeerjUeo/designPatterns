package java.State;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StateApplicationTests {

	@Test
	void contextLoads() {
	}

}
